<?php
/**
 * @package MegaMain
 * @subpackage MegaMain
 * @since mm 1.0
 */
	if( is_admin() ) {
		include_once( 'icons_modal.php' );
		include_once( 'backup_settings.php' );
		include_once( 'google_fonts_for_tinymce.php' );
	}
	include_once( 'do_shortcode.php' );
	include_once( 'g_elements_map.php' );
