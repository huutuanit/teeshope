<?php

namespace Elementor;

class Shopwise_Testimonial_Widget extends Widget_Base {

    public function get_name() {
        return 'shopwise-testimonial';
    }
    public function get_title() {
        return 'Testimonial (K)';
    }
    public function get_icon() {
        return 'eicon-slider-push';
    }
    public function get_categories() {
        return [ 'shopwise' ];
    }

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'shopwise' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
		
        $this->add_control( 'title',
            [
                'label' => esc_html__( 'Title', 'shopwise' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => 'Our Client Say!',
                'placeholder' => esc_html__( 'Enter title here', 'shopwise' )
            ]
        );
		
		$customimg = plugins_url( 'images/user_img1.jpg', __DIR__ );
		$repeater = new Repeater();
		
        $repeater->add_control( 'customer_image',
            [
                'label' => esc_html__( 'Image', 'shopwise' ),
                'type' => Controls_Manager::MEDIA,
                'default' => ['url' => $customimg],
            ]
        );
		
        $repeater->add_control( 'customer_name',
            [
                'label' => esc_html__( 'Name', 'shopwise' ),
                'type' => Controls_Manager::TEXT,
				'label_block' => true,
                'pleaceholder' => esc_html__( 'Enter the name here', 'shopwise' ),
                'default' => 'Add some text here',
            ]
        );
		
        $repeater->add_control( 'customer_position',
            [
                'label' => esc_html__( 'Position', 'shopwise' ),
                'type' => Controls_Manager::TEXT,
				'label_block' => true,
                'pleaceholder' => esc_html__( 'Enter the customer job.', 'shopwise' ),
                'default' => 'Add some text here',
            ]
        );
		
        $repeater->add_control( 'customer_comment',
            [
                'label' => esc_html__( 'Comment', 'shopwise' ),
                'type' => Controls_Manager::TEXTAREA,
                'pleaceholder' => esc_html__( 'Enter desc here', 'shopwise' ),
                'default' => 'Add some text here',
            ]
        );

        $this->add_control( 'testimonial_items',
            [
                'label' => esc_html__( 'Testimonial Items', 'shopwise' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'customer_name' => 'Lissa Castro',
                        'customer_position' => 'Designer',
                        'customer_comment' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A aliquam amet animi blanditiis consequatur debitis dicta distinctio, enim error eum iste libero modi nam natus perferendis possimus quasi sint sit tempora voluptatem.',
                        'customer_image' => ['url' => $customimg],
                    ],
                    [
                        'customer_name' => 'Alden Smith',
                        'customer_position' => 'Designer',
                        'customer_comment' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A aliquam amet animi blanditiis consequatur debitis dicta distinctio, enim error eum iste libero modi nam natus perferendis possimus quasi sint sit tempora voluptatem.',
                        'customer_image' => ['url' => $customimg],
                    ],
                    [
                        'customer_name' => 'Daisy Lana',
                        'customer_position' => 'Designer',
                        'customer_comment' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A aliquam amet animi blanditiis consequatur debitis dicta distinctio, enim error eum iste libero modi nam natus perferendis possimus quasi sint sit tempora voluptatem.',
                        'customer_image' => ['url' => $customimg],
                    ],
					
                ]
            ]
        );

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		

		echo '<div class="section bg_redon">';
		echo '<div class="container">';
		echo '<div class="row justify-content-center">';
		echo '<div class="col-md-6">';
		echo '<div class="heading_s1 text-center">';
		echo '<h2>'.esc_html($settings['title']).'</h2>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		echo '<div class="row justify-content-center">';
		echo '<div class="col-lg-9">';
		echo '<div class="testimonial_wrap testimonial_style1 carousel_slider owl-carousel owl-theme nav_style2" data-nav="true" data-dots="false" data-center="true" data-loop="true" data-autoplay="true" data-items="1">';

		
		if ( $settings['testimonial_items'] ) {
			foreach ( $settings['testimonial_items'] as $item ) {

				echo '<div class="testimonial_box">';
				echo '<div class="testimonial_desc">';
				echo '<p>'.esc_html($item['customer_comment']).'</p>';
				echo '</div>';
				echo '<div class="author_wrap">';
				echo '<div class="author_img">';
				echo '<img src="'.esc_url($item['customer_image']['url']).'" alt="user_img1" />';
				echo '</div>';
				echo '<div class="author_name">';
				echo '<h6>'.esc_html($item['customer_name']).'</h6>';
				echo '<span>'.esc_html($item['customer_position']).'</span>';
				echo '</div>';
				echo '</div>';
				echo '</div>';
				
			}
		}
		echo '</div>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		echo '</div>';
		
	}

}
