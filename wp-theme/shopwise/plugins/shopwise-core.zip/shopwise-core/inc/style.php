<?php 
/*************************************************
## Shopwise Typography
*************************************************/

function shopwise_custom_styling() { ?>

<style type="text/css">
<?php if (get_theme_mod( 'shopwise_shop_breadcrumb_bg' )) { ?>
.klb-shop-breadcrumb.page-title-area{
	background-image: url(<?php echo esc_url( wp_get_attachment_url(get_theme_mod( 'shopwise_shop_breadcrumb_bg' )) ); ?>);
}
<?php } ?>


<?php if (get_theme_mod( 'shopwise_blog_breadcrumb_bg' )) { ?>
.klb-blog-breadcrumb.page-title-area{
	background-image: url(<?php echo esc_url( wp_get_attachment_url(get_theme_mod( 'shopwise_blog_breadcrumb_bg' )) ); ?>);
}
<?php } ?>


<?php if (get_theme_mod( 'shopwise_question_box' )) { ?>
.questions-area .questions-box::before {
	background-image: url(<?php echo esc_url( wp_get_attachment_url(get_theme_mod( 'shopwise_question_box_image' )) ); ?>);
}
<?php } ?>


#preloader{
	background: #fff url('<?php echo esc_url( wp_get_attachment_url(get_theme_mod( 'shopwise_loader_image' )) ); ?>') no-repeat center center; 
}
</style>
<?php }
add_action('wp_head','shopwise_custom_styling');

?>