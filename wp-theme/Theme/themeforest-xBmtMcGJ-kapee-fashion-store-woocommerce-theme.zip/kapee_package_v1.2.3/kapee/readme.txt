Kapee � Multi-Purpose Responsive WooCommerce Theme
------------------------------

Kapee is fast, clean, highly customizable and responsive WordPress theme. This theme is appropriate for all kind of shops like fashion, electronics, furniture, accessories or suitable for any kind of WordPress website. 

Change log:


Version 1.0.0
- Initial