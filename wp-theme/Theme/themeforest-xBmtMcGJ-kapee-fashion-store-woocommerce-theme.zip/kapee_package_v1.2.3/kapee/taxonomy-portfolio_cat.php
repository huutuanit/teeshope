<?php
/**
 * The template for displaying portfolio category archive pages.
 *
 * @author 	PressLayouts
 * @package kapee
 * @since 1.0.0
 *
 */

get_header();

get_template_part( 'archive-portfolio' );

get_footer();?>