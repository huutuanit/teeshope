<?php
/*
Element: Instagram
*/
class vcInstagram extends WPBakeryShortCode {

    function __construct() {
        $this->_mapping();
        add_shortcode( 'kapee_instagram', array( $this, '_html' ) );
	}
	public function _mapping() {
		if ( !defined( 'WPB_VC_VERSION' ) ) { return; }
		
		vc_map( array(
			'name'			=> esc_html__( 'Instagram', 'kapee-extensions' ),
			'base'			=> 'kapee_instagram',
			'category' 		=> esc_html__( 'Kapee', 'kapee-extensions' ),
			'description' 	=> esc_html__( 'Instagram.', 'kapee-extensions' ),
        	'icon' 			=> KAPEE_URI.'/inc/admin/assets/images/vc-icon.png',
			'params' 		=> array(
				//General
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Title', 'kapee-extensions' ),
					'param_name' 	=> 'title',
					'description' 	=> esc_html__( 'Enter title.', 'kapee-extensions' ),
					'std' 			=> esc_html__( 'Instagram', 'kapee-extensions' ),
					'admin_label'   	=> true,
				),
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Username', 'kapee-extensions' ),
					'param_name' 	=> 'username',
					'admin_label'   	=> true,
				),
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Layout', 'kapee-extensions' ),
					'param_name' 	=> 'layout',
					'std' 			=> 'slider',
					'value'			=> array( 
						esc_html__('Grid','kapee-extensions') 	=> 'grid',
						esc_html__('Slider','kapee-extensions') => 'slider'
					),
					'admin_label'   	=> true,
				),
				array(
					'type' 				=> 'kapee_number',
					'param_name' 		=> 'number_of_photos',
					'heading' 			=> esc_html__( 'Number Of Photos', 'kapee-extensions' ),
					'description' 		=> esc_html__( 'Display maximum 12 photos.', 'kapee-extensions' ),
					'std' 				=> 8,
				),
				array(
					'type' 				=> 'dropdown',
					'param_name' 		=> 'size',
					'heading' 			=> esc_html__( 'Photo Size', 'kapee-extensions' ),
					'value' 			=> array(
						esc_html__('Thumbnail', 'kapee-extensions') => 'thumbnail',
						esc_html__('Medium', 'kapee-extensions') 	=> 'medium',
						esc_html__('Large', 'kapee-extensions') 	=> 'large',
					),
					'std' 				=> 'medium',
					"edit_field_class"	=> "vc_col-md-6",
				),
				array(
					'type' 				=> 'dropdown',
					'heading' 			=> esc_html__( 'Open Link In', 'kapee-extensions' ),
					'value' 			=> array(
						esc_html__('New window', 'kapee-extensions') 		=> '_blank',
						esc_html__('Current window', 'kapee-extensions') 	=> '_self',
					),
					'std' 				=> '_blank',
					'param_name' 		=> 'target',
					"edit_field_class"	=> "vc_col-md-6",
				),
				array(
					'type' 				=> 'checkbox',
					'param_name' 		=> 'space_between_photos',
					'heading' 			=> esc_html__( 'Add Space Between Photos', 'kapee-extensions' ),
					'value' 			=> array( esc_html__( 'Yes, please', 'kapee-extensions' ) => 1 ),
					'std' 				=> 0,
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
				),
				array(
					'type' 				=> 'kapee_number',
					'param_name' 		=> 'space_photos',
					'heading' 			=> esc_html__( 'Sapce Between Photos', 'kapee-extensions' ),
					'description' 		=> esc_html__( 'Number of space between photos.', 'kapee-extensions' ),
					'std' 				=> 5,
					'dependency' 	=> array(
						'element' 	=> 'space_between_photos',
						'value' 	=> array( '1' ),
					),
				),
				array(
					'type' 				=> 'checkbox',
					'heading' 			=> esc_html__( 'Hide Like And Comments', 'kapee-extensions' ),
					'value' 			=> array( esc_html__( 'Yes', 'kapee-extensions' ) => 1 ),
					'std' 				=> 0,
					'param_name' 		=> 'hide_like_comments',
					"edit_field_class"	=> "vc_col-md-6",
				),
				array(
					'type' 				=> 'checkbox',
					'param_name' 		=> 'show_follow_button',
					'heading' 			=> esc_html__( 'Show Follow Button', 'kapee-extensions' ),
					'value' 			=> array( esc_html__( 'Yes', 'kapee-extensions' ) => 1 ),
					'std' 				=> 0,
					"edit_field_class"	=> "vc_col-md-6",
				),
				array(
					'type' 				=> 'textfield',
					'heading' 			=> esc_html__( 'Link Text', 'kapee-extensions' ),
					'param_name' 		=> 'follow_button_text',
					'description' 		=> esc_html__( 'Enter link text.', 'kapee-extensions' ),
					'std' 				=> esc_html__( 'Follow Us', 'kapee-extensions' ),
					'dependency' 	=> array(
						'element' 	=> 'show_follow_button',
						'value' 	=> array( '1' ),
					),
					"edit_field_class"	=> "vc_col-md-6",
				),
				//Grid Settings
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Number Of Columns', 'kapee-extensions' ),
					'param_name' 	=> 'columns',
					"value" 		=> array(
						"1"  	=> 1,
						"2" 	=> 2,
						"3" 	=> 3,
						"4" 	=> 4,
						"5" 	=> 5,
						"6" 	=> 6,
						"7" 	=> 7,
						"8" 	=> 8,
					),
					'std' 			=> 5,
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'grid' ),
					),
					'group' 		=> esc_html__( 'Grid Settings', 'kapee-extensions' ),					
				),				
				array(
					'type' 				=> 'checkbox',
					'param_name' 		=> 'grid_space_between_photos',
					'heading' 			=> esc_html__( 'Remove Space Between Photos', 'kapee-extensions' ),
					'value' 			=> array( esc_html__( 'Yes, please', 'kapee-extensions' ) => 1 ),
					"edit_field_class"	=> "vc_col-md-6",
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'grid' ),
					),
					'group' 		=> esc_html__( 'Grid Settings', 'kapee-extensions' ),
				),
				//Carousel setting
				array(
					'type' 			=> 'dropdown',
					'heading' 		=> esc_html__( 'Number Of Row', 'kapee-extensions' ),
					'param_name' 	=> 'rows',
					'std' 			=> 1,
					'value'			=> array( 
						esc_html__('1 Row','kapee-extensions') 		=> 1,
						esc_html__('2 Rows','kapee-extensions') 	=> 2,
						esc_html__('3 Rows','kapee-extensions') 	=> 3,
					),
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
					'group'			=> esc_html__( 'Carousel Settings', 'kapee-extensions' ),
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Autoplay', 'kapee-extensions' ),
					'param_name' 	=> 'slider_autoplay',
					'value' 			=> array( esc_html__( 'Yes', 'kapee-extensions' ) => 1 ),
					'std' 				=> 0,
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
					'group'      	=> esc_html__( 'Carousel Settings', 'kapee-extensions' ),
				),				
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Loop', 'kapee-extensions' ),
					'param_name' 	=> 'slider_loop',
					'value' 		=> array( esc_html__( 'Yes', 'kapee-extensions' ) => 1 ),
					'std' 			=> 0,
					'description' 	=> esc_html__( 'True for infinate loop.', 'kapee-extensions' ),
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
					'group'			=> esc_html__( 'Carousel Settings', 'kapee-extensions' ),
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Center Mode', 'kapee-extensions' ),
					'param_name' 	=> 'slider_center',
					'value' 		=> array( esc_html__( 'Yes', 'kapee-extensions' ) => 1 ),
					'std' 			=> 0,
					'description' 	=> esc_html__( 'Center item. Works well with an odd number of items.', 'kapee-extensions' ),
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
					'group'			=> esc_html__( 'Carousel Settings', 'kapee-extensions' ),
				),
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Nav', 'kapee-extensions' ),
					'param_name' 	=> 'slider_nav',
					'value' 			=> array( esc_html__( 'Yes', 'kapee-extensions' ) => 1 ),
					'std' 				=> 1,
					'description' 	=> esc_html__( 'True for display navigation icon.', 'kapee-extensions' ),
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
					'group'			=> esc_html__( 'Carousel Settings', 'kapee-extensions' ),
				),	
				array(
					'type' 			=> 'checkbox',
					'heading' 		=> esc_html__( 'Dots', 'kapee-extensions' ),
					'param_name' 	=> 'slider_dots',
					'value' 			=> array( esc_html__( 'Yes', 'kapee-extensions' ) => 1 ),
					'std' 				=> 0,
					'description' 	=> esc_html__( 'True for display dots.', 'kapee-extensions' ),
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
					'group'			=> esc_html__( 'Carousel Settings', 'kapee-extensions' ),
				),
							
				array(
					"type"       	=> "dropdown",
					"heading"    	=> esc_html__("Extra large devices (large desktops, 1200px and up)", 'kapee-extensions' ),
					"param_name" 	=> "rs_extra_large",
					"value" 		=> array(
						"1"  	=> 1,
						"2" 	=> 2,
						"3" 	=> 3,
						"4" 	=> 4,
						"5" 	=> 5,
						"6" 	=> 6,
						"7" 	=> 7,
						"8" 	=> 8,
					),
					"std"        	=> 4,
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
					'group'      	=> esc_html__( 'Carousel Settings', 'kapee-extensions' ),
				),
				array(
					"type"          => "dropdown",
					"heading"       => esc_html__("Large devices (desktops, 992px and up)", 'kapee-extensions' ),
					"param_name"    => "rs_large",
					"value" 		=> array(
						"1"  	=> 1,
						"2" 	=> 2,
						"3" 	=> 3,
						"4" 	=> 4,
						"5" 	=> 5,
						"6" 	=> 6,
						"7" 	=> 7,
						"8" 	=> 8,
					),
					"std"           => 4,
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
					'group'         => esc_html__( 'Carousel Settings', 'kapee-extensions' ),
				),
				array(
					"type"          => "dropdown",
					"heading"       => esc_html__("Medium devices (tablets, 768px and up)", 'kapee-extensions' ),
					"param_name"    => "rs_medium",
					"value" 		=> array(
						"1"  	=> 1,
						"2" 	=> 2,
						"3" 	=> 3,
						"4" 	=> 4,
						"5" 	=> 5,
					),
					"std"           => 3,
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
					'group'         => esc_html__( 'Carousel Settings', 'kapee-extensions' ),
				),
				array(
					"type"          => "dropdown",
					"heading"       => esc_html__("Small devices (landscape phones, 576px and up)", 'kapee-extensions' ),
					"param_name"    => "rs_small",
					"value" 		=> array(
						"1"  	=> 1,
						"2" 	=> 2,
						"3" 	=> 3,
						"4" 	=> 4,
					),
					"std"           => 2,
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
					'group'         => esc_html__( 'Carousel Settings', 'kapee-extensions' ),
				),
				array(
					"type"          => "dropdown",
					"heading"       => esc_html__("Extra small devices (portrait phones, less than 576px)", 'kapee-extensions' ),
					"param_name"    => "rs_extra_small",
					"value" 		=> array(
						"1"  	=> 1,
						"2" 	=> 2,
					),
					"std"           => 1,
					'dependency' 	=> array(
						'element' 	=> 'layout',
						'value' 	=> array( 'slider' ),
					),
					'group'         => esc_html__( 'Carousel Settings', 'kapee-extensions' ),
				),
				( function_exists( 'vc_map_add_css_animation' ) ) ? vc_map_add_css_animation( true ) : '',
				array(
					'type' 			=> 'textfield',
					'heading' 		=> esc_html__( 'Extra class name', 'kapee-extensions' ),
					'param_name' 	=> 'el_class',
					'description' 	=> esc_html__( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'kapee-extensions' )
				),
				//Style
				array(
					'type' 			=> 'css_editor',
					'heading' 		=> esc_html__( 'CSS box', 'kapee-extensions' ),
					'param_name' 	=> 'css',
					'group' 		=> esc_html__( 'Design Options', 'kapee-extensions' )
				)
			),
		) );
	}
	
	public function _html( $atts, $content ) {
		$args = shortcode_atts( array(
			'title' 					=> 'Instagram',
			'username' 					=> '',
			'number_of_photos' 			=> '8',
			'size' 						=> 'medium',
			'target' 					=> '_blank',
			'space_between_photos'		=> 0,
			'space_photos'				=> 5,
			'hide_like_comments' 		=> 0,
			'show_follow_button'		=> 0,
			'follow_button_text' 		=> 'Follow Us',
			'layout' 					=> 'slider',
			'columns' 					=> 4,
			'grid_space_between_photos' => 0,
			'rows' 						=> 1,	
			'slider_autoplay' 			=> 0,
			'slider_loop' 				=> 0,
			'slider_center' 			=> 0,
			'slider_nav' 				=> 1,
			'slider_dots' 				=> 0,
			'rs_extra_large' 			=> 4,
			'rs_large'					=> 4,
			'rs_medium' 				=> 3,
			'rs_small' 					=> 2,
			'rs_extra_small' 			=> 1,
			'css_animation' 		=> 'none',	
			'el_class'					=> '',
			"css"            			=> "", 	
		), $atts );		
		extract($args);
		
		if( empty( $username ) ) return;
		
		$instagram_data 		= kapee_get_insta_media( $username, $number_of_photos);
		$class					= array();
		$class[]				= 'kapee-element';
		$class[]				= 'kapee-instagram';
		$class[]				= $el_class;
		$class[]				= kapee_get_css_animation($css_animation);
		$css_class 				= vc_shortcode_custom_css_class( $css, ' ' );
		$class[]				= $css_class;
		$args['class'] 			= implode(' ',array_filter($class));
		$args['id'] 			= kapee_uniqid('kapee-instagram-');
		$args['column_class'] 	= '';	
		$args['slider_class'] 	= ( $layout =='grid' && $grid_space_between_photos ) ? 'row no-gutters' : 'row';
		if($args['layout'] == 'slider'){
			$owl_data	= array(
				'slider_loop'				=> $slider_loop ? true : false,
				'slider_autoplay' 			=> $slider_autoplay ? true : false,
				'slider_center' 			=> $slider_center ? true : false,
				'slider_nav'				=> $slider_nav ? true : false,
				'slider_dots'				=> $slider_dots ? true : false,
				'slider_margin'				=> $space_between_photos ? (int)$space_photos : 0,
				'rs_extra_large' 			=> $rs_extra_large,
				'rs_large' 					=> $rs_large,
				'rs_medium' 				=> $rs_medium,
				'rs_small' 					=> $rs_small,
				'rs_extra_small' 			=> $rs_extra_small,
			);
			$slider_data	= shortcode_atts(kapee_slider_options(),$owl_data);
			global $kapee_owlparam;
			$kapee_owlparam['owlCarouselArg'][$args['id']] = $slider_data;
			$args['slider_class'] 	= 'kapee-carousel owl-carousel'; 
		}else{
			$columns_val = ( 12 / $columns  );			
			$columns = ( is_float($columns_val)) ?  $columns * 10 : $columns_val;			
			$classes[] ='col-xl-'.$columns;			
			$args['column_class'] = 'col-6 col-sm-6 col-md-4 col-xl-'.$columns;
		}
		
		$args['instagram_data'] = $instagram_data;	
		$args 					= wp_parse_args($args,$atts);
		
		ob_start();
			kapee_get_pl_templates('shortcodes/instagram',$args );	
		return ob_get_clean();
	}	
}
new vcInstagram();