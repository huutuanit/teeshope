<li><a href="javascript:void(0);" class="nav-link search_trigger"><i class="linearicons-magnifier"></i></a>
	<div class="search_wrap">
		<span class="close-search"><i class="ion-ios-close-empty"></i></span>
		<?php echo shopwise_search_modal_form(); ?>
	</div><div class="search_overlay"></div>
</li>